%!esystant

queens(_,_) :-
    % TO BE IMPLEMENTED
    fail.
