:- include('template.pl').

:- begin_tests(queens_eng).

test(qeens_1,[nondet]) :-
    queens(1,[1]).

test(queens_2,[fail]) :-
    queens(2,_).

test(queens_3,[fail]) :-
    queens(3,_).

test(queens_4,[nondet]) :-
    queens(4,[2,4,1,3]),
    queens(4,[3,1,4,2]).

test(queens_5) :-
    findall(Solution,queens(5,Solution),Solutions),
    length(Solutions,NumberOfSolutions),
    assertion(NumberOfSolutions == 10).

test(queens_6) :-
    findall(Solution,queens(6,Solution),Solutions),
    length(Solutions,NumberOfSolutions),
    assertion(NumberOfSolutions == 4).

:- end_tests(queens_eng).

:- run_tests.
:- halt.
