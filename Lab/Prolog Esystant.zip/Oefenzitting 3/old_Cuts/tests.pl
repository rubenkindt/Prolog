:- include('template.pl').


:- begin_tests(cuts_eng).

test(alwaysSucceed,[nondet]) :-
    true.

:- end_tests(cuts_eng).

:- run_tests.
:- halt.
