pred1(L,A) :-
    member(A,L).
pred1(_,2).

pred2(L,A) :-
    !,
    member(A,L).
pred2(_,2).

pred3(L,A) :-
    member(A,L),
    !.
pred3(_,2).
