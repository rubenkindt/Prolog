:- include('template.pl').
    
:- begin_tests(balanced).

%------------------------------------------------------------------------------
% balanced/1 tests

test(balanced_nil) :-
    balanced(nil).

test(balanced_1,nondet) :-
    balanced(t(nil,3,nil)).

test(balanced_2,nondet) :-
    balanced(t(nil,3,t(nil,4,nil))).

test(balanced_3_fail,fail) :-
    balanced(t(nil,3,t(nil,4,t(nil,2,nil)))).

%------------------------------------------------------------------------------
% add_to/3 tests

test(add_to_nil) :-
    add_to(nil,4,T),
    assertion(T == t(nil,4,nil)).

test(add_to,nondet) :-
    add_to(t(t(nil,3,nil),2,nil),4,T),
    assertion(T == t(t(nil,3,nil),2,t(nil,4,nil))).

:- end_tests(balanced).

:- run_tests.

:- halt.
