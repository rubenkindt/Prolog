%!esystant

% Knowledge base
teaches(holvoet,bvp).
teaches(moens,bvp).
teaches(demoen,fi).
teaches(dedecker,socs).
teaches(holvoet,swop).
teaches(jacobs,swop).
teaches(demoen,ai).
teaches(deschreye,ai).

takes(joachim,bvp).
takes(joachim,fi).
takes(joachim,ai).
takes(matthias,bvp).
takes(matthias,ai).
takes(thomas,socs).
takes(thomas,swop).
takes(ingmar,swop).


% Predicates
takes_same_course(_,_) :-
    % TO BE IMPLEMENTED
    fail.

teach_same_course(_,_) :-
    % TO BE IMPLEMENTED
    fail.

teaches_multiple_courses(_) :-
    % TO BE IMPLEMENTED
    fail.
