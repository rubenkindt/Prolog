:- include('template.pl').

:- begin_tests(moreclasses).


% takes_same_course/2 tests

test(takes_same_course_number_of_solutions) :-
    findall(pair(X,Y), takes_same_course(X,Y), Solutions),
    length(Solutions,NumberOfSolutions),
    assertion(NumberOfSolutions == 4).

test(takes_same_course_joachim_matthias) :-
    takes_same_course(joachim,matthias).

test(takes_same_course_matthias_joachim) :-
    takes_same_course(matthias,joachim).

test(takes_same_course_thomas_ingmar) :-
    takes_same_course(ingmar,thomas).

test(takes_same_course_ingmar_thomas) :-
    takes_same_course(ingmar,thomas).

test(takes_same_course_joachim_thomas,[fail]) :-
    takes_same_course(joachim,thomas).

test(takes_same_course_thomas_joachim,[fail]) :-
    takes_same_course(thomas,joachim).

test(takes_same_course_joachim_ingmar,[fail]) :-
    takes_same_course(joachim,ingmar).

test(takes_same_course_ingmar_joachim,[fail]) :-
    takes_same_course(ingmar,joachim).


% teach_same_course/2 tests

test(teach_same_course_number_of_solutions) :-
    findall(pair(X,Y), teach_same_course(X,Y), Solutions),
    length(Solutions,NumberOfSolutions),
    assertion(NumberOfSolutions == 6).

test(teach_same_course_holvoet_moens) :-
    teach_same_course(holvoet,moens).

test(teach_same_course_moens_holvoet) :-
    teach_same_course(moens,holvoet).

test(teach_same_course_holvoet_jacobs) :-
    teach_same_course(holvoet,jacobs).

test(teach_same_course_jacobs_holvoet) :-
    teach_same_course(jacobs,holvoet).

test(teach_same_course_demoen_deschreye) :-
    teach_same_course(demoen,deschreye).

test(teach_same_course_deschreye_demoen) :-
    teach_same_course(deschreye,demoen).

test(teach_same_course_holvoet_deschreye,[fail]) :-
    teach_same_course(holvoet,deschreye).

test(teach_same_course_deschreye_holvoet,[fail]) :-
    teach_same_course(deschreye,holvoet).


% teaches_multiple_courses/1 tests

test(teaches_multiple_courses_number_of_solutions) :-
    findall(X, teaches_multiple_courses(X), Solutions),
    length(Solutions,NumberOfSolutions),
    assertion(NumberOfSolutions == 2).

test(teaches_multiple_courses_holvoet) :-
    teaches_multiple_courses(holvoet).

test(teaches_multiple_courses_demoen) :-
    teaches_multiple_courses(demoen).

test(teaches_multiple_courses_deschreye,[fail]) :-
    teaches_multiple_courses(deschreye).

test(teaches_multiple_courses_jacobs,[fail]) :-
    teaches_multiple_courses(jacobs).

test(teaches_multiple_courses_dedecker,[fail]) :-
    teaches_multiple_courses(dedecker).

:- end_tests(moreclasses).

:- run_tests.
:- halt.
