:- include('template.pl').

same_solution(Solution1,Solution2) :-
    subtract(Solution1,Solution2,[]),
    subtract(Solution2,Solution1,[]).

solution(1,Solution) :-
    Solution = [
        connects(1, [pos(2, 1), pos(3, 1), pos(4, 1), pos(5, 1), pos(5, 2), pos(5, 3), pos(4, 3), pos(4, 4)]),
        connects(2, [pos(1, 1), pos(1, 2), pos(2, 2)]),
        connects(3, [pos(2, 4), pos(3, 4), pos(3, 5), pos(4, 5), pos(5, 5), pos(5, 4)]),
        connects(4, [pos(4, 2), pos(3, 2), pos(3, 3), pos(2, 3), pos(1, 3), pos(1, 4), pos(1, 5), pos(2, 5)])
    ].

solution(2,Solution) :-
    Solution = [
        connects(1, [pos(5, 1), pos(5, 2), pos(5, 3), pos(5, 4)]),
        connects(2, [pos(2, 4), pos(2, 3), pos(1, 3), pos(1, 2), pos(1, 1), pos(2, 1), pos(3, 1), pos(4, 1), pos(4, 2), pos(4, 3), pos(4, 4), pos(4, 5), pos(5, 5)]),
        connects(3, [pos(2, 2), pos(3, 2), pos(3, 3), pos(3, 4), pos(3, 5), pos(2, 5), pos(1, 5), pos(1, 4)])
    ].

solution(3,Solution) :-
    Solution = [
        connects(1, [pos(1, 3), pos(1, 2), pos(1, 1), pos(2, 1), pos(3, 1)]),
        connects(2, [pos(2, 2), pos(3, 2), pos(3, 3), pos(3, 4), pos(4, 4), pos(5, 4), pos(5, 5)]),
        connects(3, [pos(2, 3), pos(2, 4), pos(1, 4), pos(1, 5), pos(1, 6), pos(2, 6), pos(3, 6)]),
        connects(4, [pos(2, 5), pos(3, 5), pos(4, 5), pos(4, 6), pos(5, 6), pos(6, 6), pos(6, 5), pos(6, 4), pos(6, 3), pos(5, 3), pos(4, 3), pos(4, 2), pos(4, 1), pos(5, 1)]),
        connects(5, [pos(5, 2), pos(6, 2), pos(6, 1)])
    ]. 

:- begin_tests(arukone_eng).

test(puzzle1,[nondet]) :-
    solve(1,Solution),
    solution(1,ActualSolution),
    same_solution(Solution,ActualSolution).

test(puzzle2,[nondet]) :-
    solve(2,Solution),
    solution(2,ActualSolution),
    same_solution(Solution,ActualSolution).

test(puzzle3,[nondet]) :-
    solve(3,Solution),
    solution(3,ActualSolution),
    same_solution(Solution,ActualSolution).

:- end_tests(arukone_eng).

:- run_tests.
:- halt.
