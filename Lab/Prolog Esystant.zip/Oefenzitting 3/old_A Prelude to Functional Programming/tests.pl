:- include('template.pl').

:- begin_tests(map_eng).

test(map_empty) :-
    map(_,[],[]).

test(map_increment) :-
    map(increment,[1,2,3],[2,3,4]).

test(map_decrement) :-
    map(decrement,[1,2,3],[0,1,2]).

:- end_tests(map_eng).

:- run_tests.
:- halt.
