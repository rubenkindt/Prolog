%!esystant

increment(X,Y) :- Y is X + 1.

decrement(X,Y) :- Y is X - 1.

map(_,_,_) :-
    % TO BE IMPLEMENTED
    fail.

