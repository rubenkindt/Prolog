:- include('myprolog').

:- begin_tests(mainarizumu).

test(mainarizumu):-
	assertion(true).

:- end_tests(mainarizumu).

:-run_tests.
:-halt.
