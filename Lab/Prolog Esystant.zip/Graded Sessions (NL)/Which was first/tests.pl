:- include('myprolog.pl').

:- begin_tests(cards).

%------------------------------------------------------------------------------
% Test opdracht 1

test(opdr1_1a,nondet) :-
    R1 = [[.,c,c,.],
          [a,c,c,a],
          [a,c,c,a]],
    findall(Rect, color_rectangle(R1,Rect), L1),
    length(L1,NbSolutions),
    assertion(NbSolutions == 1).

test(opdr1_1b,nondet) :-
    R1 = [[.,c,c,.],
          [a,c,c,a],
          [a,c,c,a]],
    color_rectangle(R1 , Solution),
    assertion(Solution == [a-rhk(1, 4, 2, 3), c-rhk(2, 3, 1, 3)]).

test(opdr1_2a,nondet) :-
    R2 = [[b,b,b,6,6,6],
          [.,5,5,5,x,5],
          [a,5,5,c,c,5],
          [a,5,5,c,c,5],
          [a,6,6,6,6,6]],
    findall(Rect, color_rectangle(R2,Rect), L2),
    length(L2,NbSolutions),
    assertion(NbSolutions == 1).

test(opdr1_2b,nondet) :-
    R2 = [[b,b,b,6,6,6],
          [.,5,5,5,x,5],
          [a,5,5,c,c,5],
          [a,5,5,c,c,5],
          [a,6,6,6,6,6]],
    color_rectangle(R2 , Solution),
    assertion(Solution == [5-rhk(2, 6, 2, 4), 6-rhk(2, 6, 1, 5), a-rhk(1, 1, 3, 5), b-rhk(1, 3, 1, 1), c-rhk(4, 5, 3, 4), x-rhk(5, 5, 2, 2)]).

test(opdr1_3a,nondet) :-
    R3 = [[4,4],
          [7,4]],
    findall(Rect, color_rectangle(R3,Rect), L3),
    length(L3,NbSolutions),
    assertion(NbSolutions == 1).

test(opdr1_3b,nondet) :-
    R3 = [[4,4],
          [7,4]],
    color_rectangle(R3 , Solution),
    assertion(Solution == [4-rhk(1, 2, 1, 2), 7-rhk(1, 1, 2, 2)]).

test(opdr1_4a,nondet) :-
    R4 = [[.,4,3],
          [7,.,3]],
    findall(Rect, color_rectangle(R4,Rect), L4),
    length(L4,NbSolutions),
    assertion(NbSolutions == 1).

test(opdr1_4b,nondet) :-
    R4 = [[.,4,3],
          [7,.,3]],
    color_rectangle(R4 , Solution),
    assertion(Solution == [3-rhk(3,3,1,2), 4-rhk(2,2,1,1), 7-rhk(1,1,2,2)]).

%------------------------------------------------------------------------------
% Test opdracht 2

test(opdr2_1a,nondet) :-
    R1 = [[.,c,c,.],
          [a,c,c,a],
          [a,c,c,a]],
    findall(Rect, sequence(R1,Rect), L1),
    length(L1,NbSolutions),
    assertion(NbSolutions == 1).

test(opdr2_1b,nondet) :-
    R1 = [[.,c,c,.],
          [a,c,c,a],
          [a,c,c,a]],
    sequence(R1 , Solution),
    assertion(Solution == [a , c]).

test(opdr2_2a,nondet) :-
    R2 = [[b,b,b,6,6,6],
          [.,5,5,5,x,5],
          [a,5,5,c,c,5],
          [a,5,5,c,c,5],
          [a,6,6,6,6,6]],
    findall(Rect, sequence(R2,Rect), L2),
    length(L2,NbSolutions),
    assertion(NbSolutions == 1).

test(opdr2_2b,nondet) :-
    R2 = [[b,b,b,6,6,6],
          [.,5,5,5,x,5],
          [a,5,5,c,c,5],
          [a,5,5,c,c,5],
          [a,6,6,6,6,6]],
    sequence(R2 , Solution),
    assertion(Solution == [6,5,a,b,c,x]).

test(opdr2_3a,nondet) :-
    R3 = [[4,4],
          [7,4]],
    findall(Rect, sequence(R3,Rect), L3),
    length(L3,NbSolutions),
    assertion(NbSolutions == 1).

test(opdr2_3b,nondet) :-
    R3 = [[4,4],
          [7,4]],
    sequence(R3 , Solution),
    assertion(Solution == [4, 7]).

test(opdr2_4a,nondet) :-
    R4 = [[.,4,3],
          [7,.,3]],
    findall(Rect, sequence(R4,Rect), L4),
    length(L4,NbSolutions),
    assertion(NbSolutions == 1).

test(opdr2_4b,nondet) :-
    R4 = [[.,4,3],
          [7,.,3]],
    sequence(R4 , Solution),
    assertion(Solution == [3, 4, 7]).

:- end_tests(cards).
:- run_tests.

:- halt.