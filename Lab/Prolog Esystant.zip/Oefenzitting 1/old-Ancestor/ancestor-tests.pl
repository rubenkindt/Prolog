:- include('ancestor-template').

:- begin_tests(ancestor).

test(ancestor1, all(X == [bart, daan, elisa])):-
	ancestor(anton,X).


:- end_tests(ancestor).
:- run_tests.
:- halt.
