%!esystant

depth(_,_) :- fail.
