:- include('depth-template').

:- begin_tests(depth).

test(empty_tree):-
	depth(nil,X),
	assertion(X == 0).

test(tree):-
	depth(node(nil, _, node(nil, _, nil)), Y),
	assertion(Y==2).

test(tree2):-
	depth(node(nil,1,node(node(nil,3,nil),2,node(nil,4,nil))),D),
	assertion(D==3).

:- end_tests(depth).

:-run_tests.
:-halt.
