:- include('calculator-template').

:- begin_tests(calculator).

test(number_only):-
	eval(number(5), X),
	assertion(X == 5).

test(sum):-
	eval(plus(number(3),number(4)), X),
	assertion(X==7).

test(diff):-
	eval(min(number(4),number(3)), X),
	assertion(X==1).

test(neg):-
	eval(neg(plus(number(2), number(3))), X),
	assertion(X == -5).

test(eq):-
	eval(=(neg(plus(number(1), number(4))), neg(plus(number(2), number(3)))), X),
	assertion(X == tru).

test(bool):-
	eval(and(=(plus(number(3),number(4)), number(5)), not(or(fal, fal))), X),
	assertion(X == fal).

:- end_tests(calculator).

:-run_tests.
:-halt.
