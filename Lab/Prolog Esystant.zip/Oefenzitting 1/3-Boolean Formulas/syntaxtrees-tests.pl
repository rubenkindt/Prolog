:- include('syntaxtrees-template.pl').

:- begin_tests(syntax).

test(expression1):-
	eval(and(or(not(tru),tru),fal),X),
	assertion(X == fal).

:- end_tests(syntax).
:- run_tests.
:- halt.
