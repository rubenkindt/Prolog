#!/usr/bin/env python2

import sys
import json
import re
from collections import OrderedDict

# We can't always strip newlines, we need to be able to tell empty lines and
# EOF apart
def get_new_line(f):
    line = f.readline()
    # If we have a comment in this line, strip it. However, if the entire line
    # was a comment, this will remove the trailing newline, which is not what
    # we want. Add it back in.
    if '%' in line:
        line = line.split('%')[0] + '\n'
    return line

def get_new_line_stripped(f):
    return get_new_line(f).strip()

def skip_newlines(file_handle):
    line = get_new_line(file_handle)
    while line == '\n':
        line = get_new_line(file_handle)
    return line

def skip_non_test_lines(f):
    line = get_new_line(f)
    while line and not 'test' in line:
        line = get_new_line(f)
    return line

def parse_test(file_handle, header):
    expressions = ''
    # '' is a result we never expect to have. We can differ between True, False
    # and a string (e.g. X == 5)
    expected_result = ''

    # A test predicate has at least one argument (which is the name) and an
    # optional second argument. At the moment, we explicitly support [all] and
    # [fail]. [nondet] is implicitly supported.
    # A very ugly regex, which we hopefully won't ever need. It is smarter in
    # parsing terms, but should still be extended to allow returning list
    # elements one by one. Documenting just in case. If it ever gets this far,
    # I should probably write a decent parser instead of relying on regex
    # test\((\w+)(?:, ?((?:[\w, =]|\[(?2)+\]|\((?2)*\))+))?\)
    match = re.search(r'test\((\w+)(?:, ?(.+))?\)', header)
    test_name = match.group(1)
    second_arg = match.group(2)

    if second_arg:
        if second_arg.startswith('all('):
            match = re.search(r'all\(([^()]*)\)', second_arg)
            expected_result = match.group(1).split('==')[1].strip()
        elif 'fail' in second_arg:
            expected_result = False

    line = get_new_line_stripped(file_handle)
    # There should be no empty lines (or lines with only a comment) inside a
    # test!
    while line:
        if line.startswith('assertion'):
            match = re.search(r'assertion\((.*)\)', line)
            #expected_result.append(match.group(1).strip())#.split('==')[1].strip()
            expected_result = match.group(1).strip()
        else:
            expressions += line
        line = get_new_line_stripped(file_handle)
    return test_name, {
            'expression': expressions[:-1],
            'status': 'passed',
            'expected-result': expected_result if expected_result != '' else True,
            'actual-result': expected_result if expected_result != '' else True
            }

def parse_tests(filename):
    tests = OrderedDict()
    with(open(filename, 'r')) as f:
        # Find begin of tests
        line = get_new_line(f)
        while line:
            if line and not line.startswith(':- begin_tests'):
                line = get_new_line(f)
            line = skip_non_test_lines(f)
            while line.startswith('test('):
                test_name, test_json = parse_test(f, line)
                tests[test_name] = {"test-type": "unit-test", "test-result" : test_json}
                line = skip_non_test_lines(f)
    return tests

# Possible error outputs:

#ERROR: /home/tim/phd/DT/prolog/tim/oefz1/peano-tests.pl:48:
#        /home/tim/phd/DT/prolog/tim/oefz1/peano-tests.pl:42:
#        test max4: received error: plunit_max:'unit body'/2: Undefined procedure: plunit_max:maximum/3
# done

#ERROR: /home/tim/phd/esystant-content/Assignments/Prolog/Oefenzitting_1/Syntax tree/syntaxtrees-tests.pl:10:
#        /home/tim/phd/esystant-content/Assignments/Prolog/Oefenzitting_1/Syntax tree/syntaxtrees-tests.pl:5:
#        test expression1: failed
#
# done

#ERROR: /home/tim/phd/DT/prolog/tim/oefz1/sumtree-test.pl:19:
#	/home/tim/phd/DT/prolog/tim/oefz1/sumtree-test.pl:13:
#	test tree2: received error: plunit_sum:'unit body'/2: Undefined procedure: plunit_sum:sumtree/2
# done

#ERROR: /home/tim/phd/DT/prolog/tim/oefz1/peano.pl:59:
#        /home/tim/phd/DT/prolog/tim/oefz1/peano.pl:11:
#        test min2: assertion failed
#        Assertion: s(s(_G167))==s(_G167)

#ERROR: /home/tim/phd/DT/prolog/tim/oefz1/ancestor-tests.pl:9:
#        /home/tim/phd/DT/prolog/tim/oefz1/ancestor-tests.pl:4:
#        test ancestor1: received error: Out of local stack
# done

def parse_error():
    # skip first line
    first = sys.stdin.readline()
    result_line = sys.stdin.readline()
    # Test name is second word, we maybe need to strip a : at the right
    test_name = result_line.split(' ')[1].rstrip(':')
    if 'received error' in result_line:
        expected = None
        found = ' '.join(result_line.split(' ')[4:])[:-1]
    else:
        assertion_line = sys.stdin.readline().strip()
        if assertion_line.startswith('Expected'):
            expected = assertion_line.split(' ')[1]
            found = sys.stdin.readline().strip().split(' ')[1]
        else:
            expected = None
            found = False if not assertion_line else assertion_line.split(' ')[1:][0].split('=')[0]
    return test_name, expected, found

filename = sys.argv[1]
out = parse_tests(filename)
line = sys.stdin.readline()
while line:
    # No real way to distinguish between compile errors and test errors
    if line.startswith('ERROR:') and filename in line:
        test_name, expected, found = parse_error()

        if expected is not None:
            out[test_name]['test-result']['expected-result'] = expected
        # We defaulted to 'found = False' when no result was given. But now we
        # also support fail as an expected result, we actually want the inverse
        # of this expected result.
        if not found:
            found = not out[test_name]['test-result']['expected-result']
        out[test_name]['test-result']['actual-result'] = found
        # We don't distinguish between 'failed' and 'not-implemented'
        out[test_name]['test-result']['status'] = 'failed'
    line = sys.stdin.readline()

print '{'
print '\t"test-results":' + json.dumps(out.values())
print '}'
