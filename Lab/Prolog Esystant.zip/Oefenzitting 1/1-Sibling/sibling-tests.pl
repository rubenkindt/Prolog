:- include('sibling-template').

:- begin_tests(sibling).

test(sibling1):-
	\+ sibling(daan,daan).

test(sibling2):-
	\+ sibling(gerda, daan).

test(sibling3):-
	sibling(daan,X),
	assertion(X==bart).

:- end_tests(sibling).
:- run_tests.
:- halt.
