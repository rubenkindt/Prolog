:- include('peano-template.pl').

:- begin_tests(min).

test(min1, [nondet]):-
	min(s(s(s(X))), zero, Y),
	assertion(Y == s(s(s(X)))).

test(min2, [nondet]):-
	min(s(s(s(X))), s(zero), Y),
	assertion(Y == s(s(X))).

:- end_tests(min).

:- begin_tests(greater_than).

test(greater_than1, [nondet]):-
	greater_than(s(s(s(_))), zero).

test(greater_than2, [nondet]):-
	greater_than(s(s(_)), s(zero)).

test(greater_than3):-
	\+ greater_than(s(zero), s(zero)).

:- end_tests(greater_than).

:- begin_tests(max).

test(max1, [nondet]):-
	maximum(s(zero), zero, R1),
	assertion(R1 == s(zero)).

test(max2, [nondet]):-
	maximum(zero, s(zero), R2),
	assertion(R2 == s(zero)).

test(max3, [nondet]):-
	maximum(zero, zero, R3),
	assertion(R3 == zero).

test(max4, [nondet]):-
	maximum(s(s(s(zero))), s(zero), R4),
	assertion(R4 == s(s(s(zero)))).

:- end_tests(max).

:- run_tests.
:- halt.
