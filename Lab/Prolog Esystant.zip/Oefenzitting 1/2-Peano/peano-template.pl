%!esystant

min(_,_,_) :- fail.

greater_than(_,_) :- fail.

maximum(_,_,_) :- fail.
