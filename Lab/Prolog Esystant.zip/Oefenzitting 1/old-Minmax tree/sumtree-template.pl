%!esystant

minmaxtree(_,_) :- fail.
