:- include('sumtree-template').

:- begin_tests(sum).

test(tree):-
        minmaxtree(node(1-node(2-node(1-leaf(who), 3-leaf(knew)), 4-node(0-leaf(prolog), 1-leaf(was))), 3-node(4-node(5-leaf(such), 2-leaf(fun)), 6-node(2-leaf(!), 4-leaf(!)))), Result),
        assertion(Result == prolog).

:- end_tests(sum).

:-run_tests.
:-halt.
