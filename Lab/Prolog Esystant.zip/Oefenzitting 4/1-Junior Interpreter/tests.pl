:- include('template.pl').

:- begin_tests(junior_interpreter).


% interpret/1 tests

test(interpreter_fib_no_memoization_0,[nondet]) :-
    interpret(fib(0,1)).

test(interpreter_fib_no_memoization_1,[nondet]) :-
    interpret(fib(1,1)).

test(interpreter_fib_no_memoization_2,[nondet]) :-
    interpret(fib(2,2)).

test(interpreter_fib_no_memoization_3,[nondet]) :-
    interpret(fib(3,3)).

test(interpreter_fib_no_memoization_4,[nondet]) :-
    interpret(fib(4,5)).

test(interpreter_fib_no_memoization_5,[nondet]) :-
    interpret(fib(5,8)).

test(interpreter_fib_no_memoization_10,[nondet]) :-
    interpret(fib(10,89)).


% interpret_mem/1 tests

test(interpreter_fib_memoization_0,[nondet]) :-
    interpret_mem(fib(0,1)).

test(interpreter_fib_memoization_1,[nondet]) :-
    interpret_mem(fib(1,1)).

test(interpreter_fib_memoization_2,[nondet]) :-
    interpret_mem(fib(2,2)).

test(interpreter_fib_memoization_3,[nondet]) :-
    interpret_mem(fib(3,3)).

test(interpreter_fib_memoization_4,[nondet]) :-
    interpret_mem(fib(4,5)).

test(interpreter_fib_memoization_5,[nondet]) :-
    interpret_mem(fib(5,8)).

test(interpreter_fib_memoization_10,[nondet]) :-
    interpret_mem(fib(10,89)).


:- end_tests(junior_interpreter).

:- run_tests.
:- halt.
