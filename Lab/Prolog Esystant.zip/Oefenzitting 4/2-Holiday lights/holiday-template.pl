%!esystant


% Example knowledge base
highway(1,2,yellow).
highway(2,3,blue).
highway(1,3,yellow).

