:- include('holiday-template').

:- begin_tests(holiday).

test(check) :-
    check.

test(holiday):-
    tour(T),
    T = [2-yellow, 3-blue, 1-yellow].

:- end_tests(holiday).

:-run_tests.
:-halt.
