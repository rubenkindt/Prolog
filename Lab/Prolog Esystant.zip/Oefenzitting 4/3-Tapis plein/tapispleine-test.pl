:- include('tapispleine-template').

:- begin_tests(tapispleine).

solution1([wall(v,2,3,4),
   wall(v,3,0,1),
   wall(v,4,0,1),
   wall(h,2,3,5)]).
test(wallinpart1):-
  findall(P,wall_in_part(part(0,0,5,4),P),L),
  solution1(Sol),
  permutation(L,Sol).


solution2([wall(v,3,0,1),
   wall(v,4,0,1),
   wall(h,2,3,5)]).
test(wallinpart2):-
  findall(P,wall_in_part(part(2,0,5,3),P),L),
  solution2(Sol),
  permutation(L,Sol).

solution3([wall(v,4,0,1)]).
test(wallinpart3):-
  findall(P,wall_in_part(part(3,0,5,2),P),L),
  solution3(Sol),
  permutation(L,Sol).


colorsols([green,red]).
test(colorinpart):-
  findall(P,color_in_part(part(1,0,4,2),P),L),
  colorsols(Sol),
  permutation(L,Sol).

test(singlecolor) :-
  single_color_present(part(0,0,2,2)),
  assertion(true).

cutsols([
 [cut(v,4,0,4),cut(h,2,0,4),cut(v,3,0,2),cut(v,2,2,4),cut(h,2,4,5)]-[part(0,0,3,2),part(0,2,2,4),part(2,2,4,4),part(3,0,4,2),part(4,0,5,2),part(4,2,5,4)], [cut(h,2,0,5),cut(v,3,0,2),cut(v,4,0,2),cut(v,2,2,4)]-[part(0,0,3,2),part(0,2,2,4),part(2,2,5,4),part(3,0,4,2),part(4,0,5,2)], [cut(h,2,0,5),cut(v,4,0,2),cut(v,3,0,2),cut(v,2,2,4)]-[part(0,0,3,2),part(0,2,2,4),part(2,2,5,4),part(3,0,4,2),part(4,0,5,2)]]).
test(cutplan) :-
  findall((C-P),cut_plan(C,P),L),
  cutsols(Sol),
  permutation(L,Sol).

:- end_tests(tapispleine).

:-run_tests.
:-halt.
