%!esystant


% Example knowledge base
house(5,4).
wall(v,2,3,4).
wall(v,3,0,1).
wall(v,4,0,1).
wall(h,2,3,5).
color(1,1,green).
color(1,2,red).
color(3,1,red).
color(4,0,blue).


