:- include('template.pl').


:- begin_tests(quiz_eng).

test(alwaysSucceed,[nondet]) :-
    true.

:- end_tests(quiz_eng).

:- run_tests.
:- halt.
