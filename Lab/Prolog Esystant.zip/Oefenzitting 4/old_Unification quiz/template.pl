quiz(L1) :-
  length(L1, 2),
  member(a, L1),
  length(L2, 2),
  member(b, L2),
  L1 = L2.
