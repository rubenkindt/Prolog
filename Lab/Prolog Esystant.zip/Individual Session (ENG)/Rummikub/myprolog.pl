%%%%%%%%%%%%%%%%%%
%% ASSIGNMENT 1 %%
%%%%%%%%%%%%%%%%%%

valid_table(_Table) :- fail.

%%%%%%%%%%%%%%%%%%
%% ASSIGNMENT 2 %%
%%%%%%%%%%%%%%%%%%

play_game(_P1,_P2,_Table,_Bag) :- fail.

%%%%%%%%%%%%%%%%%%
%% ASSIGNMENT 3 %%
%%%%%%%%%%%%%%%%%%

count_wins(_P1Blocks,_P2Blocks,_Bag,_WinPercentage) :- fail.
