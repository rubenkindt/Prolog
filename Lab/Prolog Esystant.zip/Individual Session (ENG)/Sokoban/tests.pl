:- use_module(library(lists)).
:- include('myprolog.pl').

:- begin_tests(sokoban).

%------------------------------------------------------------------------------
% Test exercise 1

test(assignment_1) :-
    Sok1 = sokoban(7,7, (1,1), [wall((0,0),(6,0)), wall((6,0),(6,6)), wall((0,6),(6,6)), wall((0,0),(0,6)), wall((3,0),(3,2)), wall((3,4),(3,6)), crate(1,3,3), storage(1,3)]),
    assertion((findall(P,reachable(Sok1,P),L), permutation(L, [(1,1),(1,2),(1,3),(1,4),(1,5),(2,1),(2,2),(2,3),(2,4),(2,5)]))).

%------------------------------------------------------------------------------
% Test exercise 2

test(assignment_2_1) :-
  Sok = sokoban(7,7, (1,1), [wall((0,0),(6,0)), wall((6,0),(6,6)), wall((0,6),(6,6)), wall((0,0),(0,6)), wall((3,0),(3,2)), wall((3,4),(3,6)), crate(1,3,3), storage(1,3)]),
  assertion(findall(P,possible(Sok,1,P), [])).

test(assignment_2_2) :-
  Sok = sokoban(7,7, (2,3), [wall((0,0),(6,0)), wall((6,0),(6,6)), wall((0,6),(6,6)), wall((0,0),(0,6)), wall((3,0),(3,2)), wall((3,4),(3,6)), crate(1,3,3), storage(1,3)]),
  assertion((findall(P,possible(Sok,1,P), L), permutation(L, [(4,3),(5,3)]))).

test(assignment_2_3) :-
  Sok = sokoban(7,7, (4,3), [wall((0,0),(6,0)), wall((6,0),(6,6)), wall((0,6),(6,6)), wall((0,0),(0,6)), wall((3,0),(3,2)), wall((3,4),(3,6)), crate(1,5,3), storage(1,3)]),
  assertion(findall(P,possible(Sok,1,P), [])).

%------------------------------------------------------------------------------
% Test exercise 3

test(assignment_3_1) :-
    Sok = sokoban(8, 9, (2,2), [wall((2,0), (6,0)), wall((6,1), (6,5)), wall((7,5),(7,8)), wall((0,8), (7,8)), wall((0, 1), (0,8)), wall((1,1),(2,1)), wall((1,3),(2,3)), wall((2,4),(3,4)), wall((2,5),(2,5)), crate(1,3,2), crate(2,4,3), crate(3,4,4), crate(4,1,6), crate(5,3,6), crate(6,4,6), crate(7,5,6), storage(1,2), storage(5,3), storage(1,4), storage(4,5), storage(3,6), storage(6,6), storage(4,7)]),
    assertion(check(Sok,[1,6,7,1,2,3,5,4,5])).

test(assignment_3_2, fail) :-
    Sok = sokoban(8, 9, (2,2), [wall((2,0), (6,0)), wall((6,1), (6,5)), wall((7,5),(7,8)), wall((0,8), (7,8)), wall((0, 1), (0,8)), wall((1,1),(2,1)), wall((1,3),(2,3)), wall((2,4),(3,4)), wall((2,5),(2,5)), crate(1,3,2), crate(2,4,3), crate(3,4,4), crate(4,1,6), crate(5,3,6), crate(6,4,6), crate(7,5,6), storage(1,2), storage(5,3), storage(1,4), storage(4,5), storage(3,6), storage(6,6), storage(4,7)]),
    check(Sok,[6,1,7,1,2,3,5,4,5]).

test(assignment_3_3, fail) :-
    Sok = sokoban(7,7, (1,1), [wall((0,0),(6,0)), wall((6,0),(6,6)), wall((0,6),(6,6)), wall((0,0),(0,6)), wall((3,0),(3,2)), wall((3,4),(3,6)), crate(1,3,3), storage(1,3)]),
    check(Sok,[1,1]).

test(assignment_3_4) :-
    Sok = sokoban(7,7, (4,1), [wall((0,0),(6,0)), wall((6,0),(6,6)), wall((0,6),(6,6)), wall((0,0),(0,6)), wall((3,0),(3,2)), wall((3,4),(3,6)), crate(1,3,3), storage(1,3)]),
    assertion(check(Sok,[1,1])).

test(assignment_3_5) :-
    Sok = sokoban(7,7, (1,1), [wall((0,0),(6,0)), wall((6,0),(6,6)), wall((0,6),(6,6)), wall((0,0),(0,6)), wall((3,0),(3,2)), wall((3,4),(3,6)), crate(1,3,3), storage(3,3)]),
    assertion(check(Sok,[])).

test(assignment_3_6) :-
    Sok = sokoban(7,7, (1,1), [wall((0,0),(6,0)), wall((6,0),(6,6)), wall((0,6),(6,6)), wall((0,0),(0,6)), wall((3,0),(3,2)), wall((3,4),(3,6)), crate(1,3,3), storage(5,1)]),
    assertion(check(Sok,[1,1])).

:- end_tests(sokoban).
:- run_tests.

%:- halt.
