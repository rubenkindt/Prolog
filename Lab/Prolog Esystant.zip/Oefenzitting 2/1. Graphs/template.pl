%!esystant

neighbor(_,_) :-
    %TO BE IMPLEMENTED
    fail.

path(_,_) :-
    %TO BE IMPLEMENTED
    fail.

path2(X,Y) :-
    pathHelper(X,Y,[]).

%pathHelper(X,Y,Visited).
pathHelper(_,_,_) :-
    %TO BE IMPLEMENTED
    fail.
