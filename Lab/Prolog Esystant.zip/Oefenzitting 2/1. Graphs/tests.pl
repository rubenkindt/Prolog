:- include('template.pl').

:- begin_tests(graph).

:- discontiguous plunit_graph:test/3.

%------------------------------------------------------------------------------
% neighbor/2 tests

test(neighbor_symmetry,[forall((member(X,[a,b,c,d]),member(Y,[a,b,c,d]))), nondet]) :-
    (
	neighbor(X,Y) -> neighbor(Y,X)
    ;
	true
    ).

test(neighbor_given_graph,[nondet]) :-
    neighbor(b,a),
    neighbor(b,c),
    neighbor(b,d),
    neighbor(d,c).

test(neighbor_e_disconnected, fail) :-
    neighbor(e,_).

%------------------------------------------------------------------------------
% path/2 tests
test(path_a_c,[nondet]) :-
    path(a,c).

%------------------------------------------------------------------------------
% path/2 tests
test(path2_a_all_count) :-
    findall(X,path2(a,X),L),
    length(L,NoPaths),
    assertion(NoPaths == 5).

test(path2_a_e,fail) :-
    path2(a,e).

	
:- end_tests(graph).

:- run_tests.
:- halt.
