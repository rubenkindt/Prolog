:- include('template.pl').

:- begin_tests(primes).

%------------------------------------------------------------------------------
% all_primes/2 tests

test(all_primes_3) :-
    all_primes(3,L),
    assertion(L == [2,3]).

test(all_primes_15) :-
    all_primes(15,L),
    assertion(L == [2,3, 5, 7, 11, 13]).

test(all_primes_50) :-
    all_primes(50,L),
    assertion(L == [2,3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]).

:- end_tests(primes).

:- run_tests.

:- halt.
