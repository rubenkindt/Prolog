%!esystant
all_primes(_,_) :-
    % TO BE IMPLEMENTED
    fail.
