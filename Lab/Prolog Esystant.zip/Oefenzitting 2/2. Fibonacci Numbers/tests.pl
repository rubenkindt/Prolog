:- include('template.pl').

:- begin_tests(fibonacci).

%------------------------------------------------------------------------------
% fib/2 tests

test(fib_25,nondet) :-
    fib(25,N),
    assertion(N =:= 46368).

test(fib_1,nondet) :-
    fib(1,N),
    assertion(N =:= 0).

test(fib_2,nondet) :-
    fib(2,N),
    assertion(N =:= 1).

%------------------------------------------------------------------------------
% fib2/2 tests

test(fib2_25,nondet) :-
    fib2(25,N),
    assertion(N =:= 46368).

test(fib2_1,nondet) :-
    fib2(1,N),
    assertion(N =:= 0).

test(fib2_2,nondet) :-
    fib2(2,N),
    assertion(N =:= 1).


:- end_tests(fibonacci).

:- run_tests.

:- halt.
