%!esystant
fib(_,_) :-
    % TO BE IMPLEMENTED
    fail.

fib2(_,_) :-
    % TO BE IMPLEMENTED
    fail.
