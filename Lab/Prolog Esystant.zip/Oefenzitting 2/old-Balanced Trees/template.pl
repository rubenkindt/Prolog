%!esystant
    
balanced(_) :-
    % TO BE IMPLEMENTED
    fail.
    
add_to(_,_,_) :-
    % TO BE IMPLEMENTED
    fail.

add_to2(_,_,_) :-
    % TO BE IMPLEMENTED
    fail.
