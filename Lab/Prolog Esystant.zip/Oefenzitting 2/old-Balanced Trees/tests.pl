:- include('template.pl').
    
:- begin_tests(balanced).

%------------------------------------------------------------------------------
% balanced/1 tests

test(balanced_empty) :-
    balanced(empty).

test(balanced_1,nondet) :-
    balanced(node(empty,3,empty)).

test(balanced_2,nondet) :-
    balanced(node(empty,3,node(empty,4,empty))).

test(balanced_3_fail,fail) :-
    balanced(node(empty,3,node(empty,4,node(empty,2,empty)))).

%------------------------------------------------------------------------------
% add_to/3 tests

test(add_to_empty) :-
    add_to(empty,4,T),
    assertion(T == node(empty,4,empty)).

test(add_to,nondet) :-
    add_to(node(node(empty,3,empty),2,empty),4,T),
    assertion(T == node(node(empty,3,empty),2,node(empty,4,empty))).

:- end_tests(balanced).

:- run_tests.

:- halt.
