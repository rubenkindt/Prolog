:- include('template.pl').

:- begin_tests(turing_tape_eng).

test(move_right_left) :-
    move(right,Tape1,Tape2),
    move(left,Tape2,Tape1).

test(move_right_left_twice) :-
    move(right,Tape1,Tape2),
    move(right,Tape2,Tape3),
    move(left,Tape3,Tape2),
    move(left,Tape2,Tape1).

test(write_read) :-
    write_tape(Symbol,_,Tape),
    read_tape(Tape,Symbol).

test(write_move_move_read) :-
    write_tape(Symbol,_,Tape1),
    move(right,Tape1,Tape2),
    move(left,Tape2,Tape1),
    read_tape(Tape1,Symbol).

:- end_tests(turing_tape_eng).

:- run_tests.
:- halt.
