%!esystant

% move/3: Moves the head in a certain direction.
move(_,_,_) :-
    % TO BE IMPLEMENTED
    fail.

% read/2: Reads the symbol under the head.
read_tape(_,_) :-
    % TO BE IMPLEMENTED
    fail.

% write/3: Writes a symbol under the head.
write_tape(_,_,_) :-
    % TO BE IMPLEMENTED
    fail.
