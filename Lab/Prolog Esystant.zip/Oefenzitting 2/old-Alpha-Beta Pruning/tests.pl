:- include('template.pl').

:- begin_tests(alpha_beta).

%------------------------------------------------------------------------------
% alpha_beta/4

test(alpha_beta_leaf_1) :-
  alpha_beta(leaf(20,dummy),-10,10,NewS,_),
  assertion(NewS == 20).

test(alpha_beta_leaf_2) :-
  alpha_beta(leaf(20,dummy),-10,10,_,NewLeaf),
  assertion(NewLeaf == leaf(20,dummy)).

test(alpha_beta_tree_1) :-
   alpha_beta(max(
               min(
                max(leaf(1,who),leaf(3,knew)),
                max(leaf(5,prolog),leaf(1,was))),
               min(
                max(leaf(2,such),leaf(2,fun)),
                max(leaf(5,!),leaf(5,!)))),
               -10,10,S,_),
    assertion(S == 3).

test(alpha_beta_tree_1) :-
       alpha_beta(max(
               min(
                max(leaf(1,who),leaf(3,knew)),
                max(leaf(5,prolog),leaf(1,was))),
               min(
                max(leaf(2,such),leaf(2,fun)),
                max(leaf(5,!),leaf(5,!)))),
               -10,10,_,T),
    assertion(T == max(min(max(leaf(1,who),leaf(3,knew)),max(leaf(5,prolog),nil)),min(max(leaf(2,such),leaf(2,fun)),nil))).

:- end_tests(alpha_beta).

:- run_tests.

:- halt.		
