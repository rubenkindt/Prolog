%!esystant

alpha_beta(_,_,_,_,_) :-
    % TO BE IMPLEMENTED
    fail.
