:- include('template.pl').

:- begin_tests(lists).

%------------------------------------------------------------------------------
% listlength2/2 & listlength2/3 tests

test(listlength2_empty) :-
    listlength2([],N),
    assertion(N == 0).

test(listlength2_length_4) :-
    listlength2([a,b,c,d],N),
    assertion(N == 4).

test(listlength2_empty_acc) :-
    listlength2([],0,N),
    assertion(N == 0).

test(listlength2_empty_list) :-
    listlength2([],2,N),
    assertion(N == 2).

test(listlength2_non_empty_acc_and_list) :-
    listlength2([a,b,c],2,N),
    assertion(N == 5).

%------------------------------------------------------------------------------
% last/2 tests

test(last_empty,[fail]) :-
    last([],_).

test(last_singleton,[nondet]) :-
    last([b],X),
    assertion(X == b).

test(last_1_2_a,[nondet]) :-
    last([1,2,a],X),
    assertion(X == a).

%------------------------------------------------------------------------------
% next_to/3 tests

test(next_to_yes,[nondet]) :-
    next_to([a,b,c,d],b,c).

test(next_to_no,[fail]) :-
    next_to([a,b,c,d],a,c).

test(next_to_choice,[nondet]) :-
    next_to([a,b,c,d,a,b],a,b).

test(next_to_repeat,[nondet]) :-
    next_to([a,a,b,c,d],a,b).

%------------------------------------------------------------------------------
% vector_sum/3 tests

test(vector_sum) :-
    vector_sum([1,2,3],[4,5,6],L),
    assertion(L == [5,7,9]).

test(vector_sum_empty) :-
    vector_sum([],[],L),
    assertion(L == []).

%------------------------------------------------------------------------------
% look_up/2 tests

test(look_up_yes,[nondet]) :-
    look_up([pair(tom,14),pair(bart,17),pair(daan,19)],bart,Grade),
    assertion(Grade == 17).

test(look_up_no,[fail]) :-
    look_up([pair(tom,14),pair(bart,17),pair(daan,19)],pieter,_).

:- end_tests(lists).

:- run_tests.
:- halt.
