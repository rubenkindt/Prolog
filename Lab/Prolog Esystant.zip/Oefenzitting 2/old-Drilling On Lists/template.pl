%!esystant

listlength([],0).
listlength([_|Rest],Length) :-
    listlength(Rest,LengthRest),
    Length is LengthRest + 1.

listlength2(List,Length) :-
    listlength2(List,0,Length).

% listlength2(List,Accumulator,Length).
listlength2(_,_,_) :-
    % TO BE IMPLEMENTED.
    fail.

last(_,_) :-
    % TO BE IMPLEMENTED
    fail.

next_to(_,_,_) :-
    % TO BE IMPLEMENTED
    fail.

vector_sum(_,_,_) :-
    % TO BE IMPLEMENTED
    fail.

look_up(_,_,_) :-
    % TO BE IMPLEMENTED
    fail.
