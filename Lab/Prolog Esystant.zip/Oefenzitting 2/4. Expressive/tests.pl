:- include('template.pl').

:- begin_tests(expressive).

%------------------------------------------------------------------------------
% eval/3 tests

test(eval_1) :-
    eval(min(int(3)),[],Value),
    assertion(Value == -3).

test(eval_2,nondet) :-
    eval(plus(int(2),var(x)),[pair(x,3)],Value),
    assertion(Value == 5).

% { x = 2, y = 3, z = 5 } |- x^y - (3z + (-y)) -*-> -4
test(eval_3,nondet) :-
    eval(plus(pow(var(x),var(y)),min(plus(times(int(3),var(z)),min(var(y))))),
	 [pair(x,2),pair(y,3),pair(z,5)],
	 Value),
    assertion(Value == -4).

:- end_tests(expressive).

:- run_tests.

:- halt.
